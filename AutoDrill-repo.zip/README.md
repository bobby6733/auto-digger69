# AutoDrill (Paper 1.21.11)

Server plugin: `/drill` opens a GUI to pick hole size (1x1 to 9x9), speed, and depth,
then drills forward (or down if you look down) smoothly, auto-moving you along.

- Needs permission `autodrill.use` (op by default)
- Build: push to GitHub -> Actions -> download the `AutoDrill` artifact, or run `mvn package`
- Drop `AutoDrill.jar` into your server's `plugins/` folder
